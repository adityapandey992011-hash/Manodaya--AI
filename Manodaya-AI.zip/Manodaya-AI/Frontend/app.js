const API = "http://192.168.1.4:3001";

const authSection = document.getElementById("authSection");
const studentDashboard = document.getElementById("studentDashboard");
const authMessage = document.getElementById("authMessage");

const registerForm = document.getElementById("registerForm");
const loginForm = document.getElementById("loginForm");

const loggedStudentName = document.getElementById("loggedStudentName");
const loggedStudentClass = document.getElementById("loggedStudentClass");
const loggedStudentStream = document.getElementById("loggedStudentStream");

const logoutButton = document.getElementById("logoutButton");

let token = localStorage.getItem("manodayaToken") || "";
let currentStudent = null;

// ===============================
// STUDENT DASHBOARD
// ===============================

function showDashboard(student) {
  if (!student) return;
  currentStudent = student;
  authSection.hidden = true;
  studentDashboard.hidden = false;
  loggedStudentName.textContent = student.name || "Student";
  loggedStudentClass.textContent = student.studentClass || "Not selected";
  loggedStudentStream.textContent = student.stream || "Not selected";
}
const editProfileBtn = document.getElementById("editProfileBtn");

if (editProfileBtn) {
  editProfileBtn.onclick = function () {
    if (!currentStudent) {
      alert("Student Data नहीं मिला। कृपया दोबारा Login करें।");
      return;
    }

    const form = document.getElementById("editProfileForm");
    const editStream = document.getElementById("editStream");
    const subjectsList = document.getElementById("editSubjectsList");

    form.hidden = false;

    document.getElementById("editName").value = currentStudent.name || "";
    document.getElementById("editClass").value = currentStudent.studentClass || "11";
    editStream.value = currentStudent.stream || "PCB";

    function showEditSubjects() {
      subjectsList.innerHTML = "";

      const subjects = streamSubjects[editStream.value] || [];

      subjects.forEach(function (subject) {
        const label = document.createElement("label");
        const checkbox = document.createElement("input");

        checkbox.type = "checkbox";
        checkbox.name = "editSubjects";
        checkbox.value = subject;
        checkbox.checked = (currentStudent.subjects || []).includes(subject);

        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(" " + subject));
        subjectsList.appendChild(label);
      });
    }

    showEditSubjects();
    editStream.onchange = showEditSubjects;

    document.getElementById("saveProfileBtn").onclick = async function () {
      const data = {
        name: document.getElementById("editName").value.trim(),
        studentClass: document.getElementById("editClass").value,
        stream: editStream.value,
        subjects: Array.from(
          document.querySelectorAll('input[name="editSubjects"]:checked')
        ).map(input => input.value)
      };

      try {
        const response = await fetch(API + "/api/profile", {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
          },
          body: JSON.stringify(data)
        });

        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.message || "Update नहीं हुआ।");
        }

        Object.assign(currentStudent, result.student);
        form.hidden = true;
        showDashboard(currentStudent);

        alert("Profile सफलतापूर्वक Update हो गई!");
      } catch (error) {
        alert(error.message);
      }
    };

    document.getElementById("cancelProfileBtn").onclick = function () {
      form.hidden = true;
    };
  };
}
// ===============================
// STUDENT REGISTRATION
// ===============================

registerForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const data = {
    name: document.getElementById("registerName").value.trim(),
    username: document.getElementById("registerUsername").value.trim(),
    password: document.getElementById("registerPassword").value,
    studentClass: document.getElementById("registerClass").value,
    stream: document.getElementById("registerStream").value,

    subjects: Array.from(
      document.querySelectorAll('input[name="subjects"]:checked')
    ).map(input => input.value)
  };

  if (!data.stream) {
    authMessage.textContent = "कृपया अपनी Stream चुनें।";
    return;
  }

  authMessage.textContent = "Account बनाया जा रहा है...";

  try {
    const response = await fetch(API + "/api/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Registration असफल रही।");
    }

    token = result.token;
    localStorage.setItem("manodayaToken", token);
    registerForm.reset();

    authMessage.textContent = "Account सफलतापूर्वक बन गया!";
    showDashboard(result.student);

  } catch (error) {
    authMessage.textContent = error.message;
  }
});


// ===============================
// STUDENT LOGIN
// ===============================

loginForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const data = {
    username: document.getElementById("loginUsername").value.trim(),
    password: document.getElementById("loginPassword").value
  };

  authMessage.textContent = "Login हो रहा है...";

  try {
    const response = await fetch(API + "/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();  

    if (!response.ok) {  
      throw new Error(result.message || "Login असफल रहा।");  
    }  

    token = result.token;  
    localStorage.setItem("manodayaToken", token);  
    loginForm.reset();  
    authMessage.textContent = "Login सफल रहा!";  
    showDashboard(result.student);

  } catch (error) {
    authMessage.textContent = error.message;
  }
});

// ===============================
// LOGOUT
// ===============================

logoutButton.addEventListener("click", async function () {
  try {
    await fetch(API + "/api/logout", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token
      }
    });
  } catch (error) {
    console.error(error);
  }

  token = "";
  localStorage.removeItem("manodayaToken");
  showAuth();
});

// ===============================
// RESTORE LOGIN SESSION
// ===============================

async function checkSession() {
  if (!token) {
    showAuth();
    return;
  }

  try {
    const response = await fetch(API + "/api/me", {
      headers: {
        Authorization: "Bearer " + token
      }
    });

    const result = await response.json();  

    if (!response.ok) {  
      throw new Error("Session समाप्त हो गया।");  
    }  

    showDashboard(result.student);

  } catch (error) {
    token = "";
    localStorage.removeItem("manodayaToken");  
    showAuth();
  }
}

// ===============================
// PROFILE
// ===============================

const saveProfile = document.getElementById("saveProfile");
const studentName = document.getElementById("studentName");
const profileMessage = document.getElementById("profileMessage");

if (saveProfile) {
  const savedName = localStorage.getItem("manodayaProfileName");

  if (savedName && studentName) {
    studentName.value = savedName;
    profileMessage.textContent = "Welcome back, " + savedName;
  }

  saveProfile.addEventListener("click", function () {
    const name = studentName.value.trim();

    if (!name) {  
      profileMessage.textContent = "कृपया अपना नाम लिखें।";  
      return;  
    }  

    localStorage.setItem("manodayaProfileName", name);  
    profileMessage.textContent = "Profile सफलतापूर्वक Save हो गई!";
  });
}

// =====================================
// MANODAYA AI - SMART OFFLINE ASSISTANT
// =====================================

const chatForm = document.getElementById("chatForm");
const userMessage = document.getElementById("userMessage");
const chatBox = document.getElementById("chatBox");

function addMessage(message, className) {
  const div = document.createElement("div");
  div.className = className;
  div.textContent = message;

  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function getBotReply(message) {
  const text = message.toLowerCase().trim();

  if (/hello|hi|hey|नमस्ते|नमस्कार/.test(text)) {
    return "नमस्ते! मैं Manodaya AI हूँ। 📚 मैं आपकी पढ़ाई, NEET तैयारी और Study Planning में मदद कर सकता हूँ।";
  }
  if (/your name|who are you|तुम कौन|आप कौन|तुम्हारा नाम/.test(text)) {
    return "मेरा नाम Manodaya AI है। मैं आपका Personal Learning Assistant हूँ।";
  }
  if (/neet|नीट/.test(text)) {
    return "🎯 NEET Preparation के लिए तीन मुख्य विषय हैं:\n\n1. Biology – NCERT आधारित अध्ययन\n2. Chemistry – Concepts और Reactions\n3. Physics – Concepts और Numericals\n\nआप किस विषय से शुरुआत करना चाहते हैं?";
  }
  if (/biology|जीव विज्ञान|जीवविज्ञान/.test(text)) {
    return "🧬 Biology Learning Center:\n\n• The Living World\n• Biological Classification\n• Plant Kingdom\n• Animal Kingdom\n• Cell: The Unit of Life\n• Biomolecules\n• Human Physiology\n\nकिस Topic के बारे में जानना चाहते हैं?";
  }
  if (/cell|कोशिका/.test(text)) {
    return "🧫 Cell (कोशिका) जीवों की संरचनात्मक और क्रियात्मक इकाई है। इसके मुख्य भाग हैं:\n\n• Cell Membrane\n• Cytoplasm\n• Nucleus\n• Cell Organelles\n\nक्या आप Cell का Diagram या Notes चाहते हैं?";
  }
  if (/physics|भौतिक विज्ञान|भौतिकी/.test(text)) {
    return "⚡ Physics Learning Center:\n\n• Units and Measurements\n• Motion in a Straight Line\n• Motion in a Plane\n• Laws of Motion\n• Work, Energy and Power\n• Gravitation\n\nआपको Notes, Formula या Numericals में से किसकी सहायता चाहिए?";
  }
  if (/chemistry|रसायन विज्ञान|रसायन/.test(text)) {
    return "⚗️ Chemistry Learning Center:\n\n• Some Basic Concepts of Chemistry\n• Structure of Atom\n• Classification of Elements\n• Chemical Bonding\n• Redox Reactions\n\nआप कौन-सा Chapter पढ़ना चाहते हैं?";
  }
  if (/math|गणित|mathematics/.test(text)) {
    return "📐 Mathematics में Algebra, Trigonometry, Calculus और Statistics जैसे Topics पढ़ सकते हैं। किस Topic में सहायता चाहिए?";
  }
  if (/notes|नोट्स|लिखित सामग्री/.test(text)) {
    return "📚 Notes के लिए Dashboard में Smart Study Notes खोलें। वहाँ Stream, Subject और Chapter चुन सकते हैं। अभी Notes Section में उपलब्ध Chapters की सूची और Placeholder Content है।";
  }
  if (/timetable|time table|समय सारणी|टाइम टेबल/.test(text)) {
    return "🗓️ अपना Weekly Study Timetable बनाने के लिए Smart Study Timetable Section खोलें। Day, Subject, Time और Duration चुनकर Task जोड़ें।";
  }
  if (/timer|pomodoro|focus|टाइमर|ध्यान/.test(text)) {
    return "⏱️ Smart Focus Timer में 25 मिनट पढ़ाई और 5 मिनट ब्रेक का Session उपलब्ध है। Focus Timer Section खोलकर Start दबाएँ।";
  }
  if (/progress|performance|प्रगति|कितनी पढ़ाई/.test(text)) {
    return "📊 My Study Progress Section में Total Tasks, Completed Tasks, Remaining Tasks और Completion Percentage देख सकते हैं।";
  }
  if (/streak|achievement|उपलब्धि/.test(text)) {
    return "🔥 Daily Study Streak Section आपकी लगातार पढ़ाई के दिनों और Achievements को दिखाता है। Streak के लिए Study Task पूरा करें।";
  }
  if (/quiz|test|प्रश्न|क्विज|परीक्षा/.test(text)) {
    return "🧠 Smart Quiz Center खोलें। Biology, Physics या Chemistry चुनकर उपलब्ध Quiz शुरू करें।";
  }
  if (/commerce|accountancy|business studies|वाणिज्य/.test(text)) {
    return "📊 Commerce में Accountancy, Business Studies और Economics जैसे विषय शामिल हैं।";
  }
  if (/arts|humanities|history|geography|राजनीति विज्ञान/.test(text)) {
    return "🎨 Arts / Humanities में History, Geography, Political Science, Sociology और Psychology जैसे विषय पढ़ सकते हैं।";
  }
  if (/agriculture|कृषि|crop|फसल/.test(text)) {
    return "🌱 Agriculture में Crop Production, Soil Science, Horticulture और Agricultural Economics जैसे Topics शामिल हैं।";
  }
  if (/english|अंग्रेजी|grammar|व्याकरण|translation|अनुवाद/.test(text)) {
    return "📖 English Learning में Grammar, Tenses, Vocabulary, Translation और Reading Practice कर सकते हैं।";
  }
  if (/thank you|thanks|धन्यवाद|शुक्रिया/.test(text)) {
    return "आपका स्वागत है! 😊 पढ़ाई में नियमित रहें और रोज थोड़ा बेहतर करने की कोशिश करें।";
  }
  if (/bye|goodbye|अलविदा/.test(text)) {
    return "फिर मिलेंगे! अपनी पढ़ाई जारी रखें। 📚";
  }
  if (/help|मदद|क्या कर सकते/.test(text)) {
    return "🤖 मैं इन विषयों में सहायता कर सकता हूँ:\n\n1. NEET Preparation\n2. Biology, Physics, Chemistry\n3. Class 11–12 Topics\n4. Study Notes Section\n5. Quiz Center\n6. Study Timetable\n7. Focus Timer\n8. Study Progress\n\nकिस विषय से शुरुआत करें?";
  }

  return "मैं अभी Offline Assistant हूँ। इस सवाल का जवाब मेरे मौजूदा ज्ञान में उपलब्ध नहीं है।\n\nआप अपना सवाल इन विषयों पर पूछ सकते हैं: NEET, Biology, Physics, Chemistry, English या Study Planning.\n\nअधिक विस्तृत AI उत्तरों के लिए बाद में API जोड़ी जाएगी।";
}

// ===============================
// DAILY MISSIONS
// ===============================

const missionCheckboxes = document.querySelectorAll(".mission");
const missionsDisplay = document.getElementById("missions");

function updateMissions() {
  let completed = 0;
  missionCheckboxes.forEach(function (checkbox) {
    if (checkbox.checked) {
      completed++;
    }
  });
  if (missionsDisplay) {
    missionsDisplay.textContent = completed + " /3";
  }
}

missionCheckboxes.forEach(function (checkbox) {
  checkbox.addEventListener("change", updateMissions);
});

updateMissions();

// ===============================
// XP POINTS & CHAT SUBMIT
// ===============================

chatForm.addEventListener("submit", async function(event) {
  event.preventDefault();

  const message = userMessage.value.trim();
  if (!message) return;

  addMessage(message, "user-message");

  let reply = getBotReply(message);
  const token = localStorage.getItem("manodayaToken");

  if (token) {
    try {
      const response = await fetch(API+"/api/intelligence/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ question: message })
      });

      const result = await response.json();  

      if (response.ok && result.analysis) {  
        reply += "\n\n📘 विषय: " + result.analysis.subject;  
        reply += "\n🎯 सवाल का प्रकार: " + result.analysis.intent;  
      }  
    } catch (error) {  
      console.warn("Intelligence Engine उपलब्ध नहीं है।");  
    }
  }

  addMessage(reply, "bot-message");
  userMessage.value = "";
  userMessage.focus();

  if (token) {
    try {
      await fetch(API+"/api/history", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },
        body: JSON.stringify({
          userMessage: message,
          botReply: reply
        })
      });
    } catch (error) {
      console.warn("Chat History सेव नहीं हुई।");
    }
  }
});

const xpDisplay = document.getElementById("xp");

function updateXPDisplay() {
  const savedXP = Number(localStorage.getItem("manodayaXP")) || 0;
  if (xpDisplay) {
    xpDisplay.textContent = savedXP;
  }
}

updateXPDisplay();

// ===============================
// SMART QUIZ QUESTIONS & LOGIC
// ===============================

const quizQuestions = {
  biology: [
    { question: "कोशिका की खोज किसने की थी?", options: ["Robert Hooke", "Darwin", "Mendel", "Schleiden"], answer: 0, explanation: "Robert Hooke ने 1665 में कोशिका की खोज की थी।" },
    { question: "कोशिका का Powerhouse किसे कहते हैं?", options: ["Nucleus", "Mitochondria", "Ribosome", "Golgi body"], answer: 1, explanation: "Mitochondria को कोशिका का Powerhouse कहते हैं।" },
    { question: "प्रकाश संश्लेषण किसमें होता है?", options: ["Mitochondria", "Nucleus", "Chloroplast", "Ribosome"], answer: 2, explanation: "प्रकाश संश्लेषण Chloroplast में होता है।" }
  ],
  physics: [
    { question: "बल का SI मात्रक क्या है?", options: ["Joule", "Newton", "Watt", "Pascal"], answer: 1, explanation: "बल का SI मात्रक Newton है।" },
    { question: "चाल का सूत्र क्या है?", options: ["दूरी / समय", "समय / दूरी", "दूरी × समय", "बल / द्रव्यमान"], answer: 0, explanation: "चाल = तय की गई दूरी / लगा समय।" },
    { question: "कार्य का SI मात्रक क्या है?", options: ["Newton", "Watt", "Joule", "Metre"], answer: 2, explanation: "कार्य का SI मात्रक Joule है।" }
  ],
  chemistry: [
    { question: "पानी का रासायनिक सूत्र क्या है?", options: ["CO2", "H2O", "O2", "NaCl"], answer: 1, explanation: "पानी का रासायनिक सूत्र H2O है।" },
    { question: "परमाणु का केंद्र क्या कहलाता है?", options: ["Electron", "Shell", "Nucleus", "Orbit"], answer: 2, explanation: "परमाणु के केंद्र को Nucleus कहते हैं।" },
    { question: "इलेक्ट्रॉन पर कौन-सा आवेश होता है?", options: ["धनात्मक", "ऋणात्मक", "उदासीन", "कोई नहीं"], answer: 1, explanation: "इलेक्ट्रॉन पर ऋणात्मक आवेश होता है।" }
  ]
};

const quizSubject = document.getElementById("quizSubject");
const startQuiz = document.getElementById("startQuiz");
const quizArea = document.getElementById("quizArea");
const quizResult = document.getElementById("quizResult");

const questionNumber = document.getElementById("questionNumber");
const questionText = document.getElementById("questionText");
const quizOptions = document.getElementById("quizOptions");

const nextQuestion = document.getElementById("nextQuestion");
const quizScore = document.getElementById("quizScore");
const restartQuiz = document.getElementById("restartQuiz");

let currentQuestions = [];
let currentQuestionIndex = 0;
let correctAnswers = 0;
let selectedAnswer = null;

function showQuizQuestion() {
  const question = currentQuestions[currentQuestionIndex];
  selectedAnswer = null;
  nextQuestion.disabled = true;

  nextQuestion.textContent =
    currentQuestionIndex === currentQuestions.length - 1
      ? "Finish Quiz"
      : "Next Question";

  questionNumber.textContent =
    "Question " + (currentQuestionIndex + 1) + " / " + currentQuestions.length;

  questionText.textContent = question.question;
  quizOptions.innerHTML = "";

  question.options.forEach(function (option, index) {
    const button = document.createElement("button");
    button.textContent = option;  
    button.className = "quiz-option";  

    button.addEventListener("click", function () {  
      if (selectedAnswer !== null) return;  
      selectedAnswer = index;  

      const buttons = quizOptions.querySelectorAll("button");  
      buttons.forEach(function (item, i) {  
        item.disabled = true;  
        if (i === question.answer) {  
          item.classList.add("correct");  
        } else if (i === index) {  
          item.classList.add("wrong");  
        }  
      });  

      if (index === question.answer) {  
        correctAnswers++;  
      }  

      const explanation = document.createElement("p");  
      explanation.className = "quiz-explanation";  
      explanation.textContent =  
        (index === question.answer ? "सही उत्तर! " : "गलत उत्तर। ") +  
        question.explanation;  

      quizOptions.appendChild(explanation);  
      nextQuestion.disabled = false;  
    });  

    quizOptions.appendChild(button);
  });
}

startQuiz.addEventListener("click", function () {
  const subject = quizSubject.value;
  if (!subject || !quizQuestions[subject]) {
    alert("कृपया Subject चुनें।");
    return;
  }

  currentQuestions = quizQuestions[subject];
  currentQuestionIndex = 0;
  correctAnswers = 0;

  quizResult.hidden = true;
  quizArea.hidden = false;

  quizResult.querySelectorAll(".quiz-reward").forEach(function (item) {
    item.remove();
  });

  showQuizQuestion();
});

nextQuestion.addEventListener("click", function () {
  currentQuestionIndex++;
  if (currentQuestionIndex < currentQuestions.length) {
    showQuizQuestion();
  } else {
    finishQuiz();
  }
});

function finishQuiz() {
  quizArea.hidden = true;
  quizResult.hidden = false;

  const total = currentQuestions.length;
  const percentage = Math.round((correctAnswers / total) * 100);

  quizScore.textContent =
    "आपका Score: " + correctAnswers + " / " + total + " (" + percentage + "%)";

  const earnedXP = correctAnswers * 10;
  const oldXP = Number(localStorage.getItem("manodayaXP")) || 0;
  const newXP = oldXP + earnedXP;

  localStorage.setItem("manodayaXP", newXP);
  updateXPDisplay();

  const reward = document.createElement("p");
  reward.className = "quiz-reward";
  reward.textContent = "⭐ आपने " + earnedXP + " XP कमाए!";
  quizResult.appendChild(reward);
}

restartQuiz.addEventListener("click", function () {
  quizResult.hidden = true;
  quizArea.hidden = true;
  quizSubject.value = "";
  quizScore.textContent = "";
});

checkSession();
console.log("Manodaya AI loaded successfully!");

// ===============================
// SMART STUDY NOTES SYSTEM
// ===============================

const streamSubjects = {
  PCB: ["Physics", "Chemistry", "Biology", "English", "Physical Education"],
  PCM: ["Physics", "Chemistry", "Mathematics", "English", "Computer Science"],
  PCMB: ["Physics", "Chemistry", "Biology", "Mathematics", "English"],
  Commerce: ["Accountancy", "Business Studies", "Economics", "English", "Mathematics", "Informatics Practices"],
  Arts: ["History", "Geography", "Political Science", "Psychology", "Sociology", "English", "Economics"],
  Agriculture: ["Agriculture", "Biology", "Chemistry", "Physics", "English", "Agricultural Economics"],
  Vocational: ["English", "Business Studies", "Computer Science", "Entrepreneurship", "Skill Subject"]
};

const subjectChapters = {
  Physics: ["Units and Measurements", "Motion in a Straight Line", "Motion in a Plane", "Laws of Motion", "Work, Energy and Power", "System of Particles and Rotational Motion", "Gravitation", "Mechanical Properties of Solids", "Mechanical Properties of Fluids", "Thermal Properties of Matter", "Thermodynamics", "Kinetic Theory", "Oscillations", "Waves"],
  Chemistry: ["Some Basic Concepts of Chemistry", "Structure of Atom", "Classification of Elements", "Chemical Bonding", "Chemical Thermodynamics", "Equilibrium", "Redox Reactions", "Organic Chemistry", "Hydrocarbons"],
  Biology: ["The Living World", "Biological Classification", "Plant Kingdom", "Animal Kingdom", "Morphology of Flowering Plants", "Anatomy of Flowering Plants", "Structural Organisation in Animals", "Cell: The Unit of Life", "Biomolecules", "Cell Cycle and Cell Division", "Photosynthesis", "Respiration in Plants", "Plant Growth and Development", "Breathing and Exchange of Gases", "Body Fluids and Circulation", "Excretory Products and their Elimination", "Locomotion and Movement", "Neural Control and Coordination", "Chemical Coordination and Integration"],
  Mathematics: ["Sets", "Relations and Functions", "Trigonometric Functions", "Complex Numbers", "Linear Inequalities", "Permutations and Combinations", "Binomial Theorem", "Sequences and Series", "Straight Lines", "Conic Sections", "Introduction to Three Dimensional Geometry", "Limits and Derivatives", "Statistics", "Probability"]
};

const notesStream = document.getElementById("notesStream");
const notesSubject = document.getElementById("notesSubject");
const notesChapter = document.getElementById("notesChapter");
const showNotes = document.getElementById("showNotes");

const notesContent = document.getElementById("notesContent");
const notesTitle = document.getElementById("notesTitle");
const notesText = document.getElementById("notesText");

function fillSelect(select, items, firstText) {
  select.innerHTML = "";
  const firstOption = document.createElement("option");
  firstOption.value = "";
  firstOption.textContent = firstText;
  select.appendChild(firstOption);

  items.forEach(item => {
    const option = document.createElement("option");
    option.value = item;
    option.textContent = item;
    select.appendChild(option);
  });
}

if (notesStream) {
  notesStream.addEventListener("change", function () {
    const stream = notesStream.value;
    fillSelect(notesSubject, streamSubjects[stream] || [], "Select Subject");
    fillSelect(notesChapter, [], "Select Chapter");

    notesSubject.disabled = !stream;
    notesChapter.disabled = true;
    showNotes.disabled = true;
    notesContent.hidden = true;
  });
}

if (notesSubject) {
  notesSubject.addEventListener("change", function () {
    const subject = notesSubject.value;
    fillSelect(notesChapter, subjectChapters[subject] || [], "Select Chapter");

    notesChapter.disabled = !subject;
    showNotes.disabled = true;
    notesContent.hidden = true;
  });
}

if (notesChapter) {
  notesChapter.addEventListener("change", function () {
    showNotes.disabled = !notesChapter.value;
    notesContent.hidden = true;
  });
}

if (showNotes) {
  showNotes.addEventListener("click", function () {
    const subject = notesSubject.value;
    const chapter = notesChapter.value;

    if (!subject || !chapter) return;

    notesTitle.textContent = subject + " - " + chapter;
    notesText.textContent = "इस अध्याय के विस्तृत हिंदी Notes, महत्वपूर्ण परिभाषाएँ, मुख्य बिंदु, उदाहरण और अभ्यास प्रश्न यहाँ जोड़े जाएँगे।";
    notesContent.hidden = false;
  });
}

// ===============================
// REGISTRATION SUBJECT SELECTION
// ===============================

const registerStream = document.getElementById("registerStream");
const registerSubjectsList = document.getElementById("registerSubjectsList");

if (registerStream && registerSubjectsList) {
  registerStream.addEventListener("change", function () {
    const selectedStream = registerStream.value;
    const subjects = streamSubjects[selectedStream] || [];

    registerSubjectsList.innerHTML = "";

    subjects.forEach(function (subject) {
      const label = document.createElement("label");

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.name = "subjects";
      checkbox.value = subject;
      checkbox.checked = true;

      label.appendChild(checkbox);
      label.appendChild(document.createTextNode(" " + subject));

      registerSubjectsList.appendChild(label);
    });
  });
}

// ===============================
// SMART STUDY TIMETABLE SYSTEM
// ===============================

const addStudyTaskButton = document.getElementById("addStudyTask");
const studyTaskList = document.getElementById("studyTaskList");

let studyTasks = JSON.parse(localStorage.getItem("manodayaStudyTasks") || "[]");

function displayStudyTasks() {
  if (!studyTaskList) return;
  studyTaskList.innerHTML = "";

  if (studyTasks.length === 0) {
    studyTaskList.innerHTML = "<p>अभी कोई Study Task नहीं है।</p>";
    return;
  }

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  days.forEach(day => {
    const dayTasks = studyTasks.filter(task => task.day === day);
    if (dayTasks.length === 0) return;  

    const heading = document.createElement("h4");  
    heading.textContent = day;  
    studyTaskList.appendChild(heading);  

    dayTasks.forEach(task => {  
      const item = document.createElement("div");  
      item.className = "study-task";  

      const details = document.createElement("span");  
      details.textContent = `${task.time} | ${task.subject} | ${task.duration} मिनट`;  

      const status = document.createElement("span");  
      status.textContent = task.completed ? " ✓ Completed" : " Pending";  

      const completeButton = document.createElement("button");  
      completeButton.textContent = task.completed ? "Undo" : "Mark Complete";  

      completeButton.addEventListener("click", () => {  
        task.completed = !task.completed;  
        saveStudyTasks();  
        displayStudyTasks();  
        updateStudyProgress();
      });  

      const deleteButton = document.createElement("button");  
      deleteButton.textContent = "Delete";  

      deleteButton.addEventListener("click", () => {  
        studyTasks = studyTasks.filter(savedTask => savedTask.id !== task.id);  
        saveStudyTasks();  
        displayStudyTasks();  
        updateStudyProgress();
      });  

      item.appendChild(details);  
      item.appendChild(status);  
      item.appendChild(completeButton);  
      item.appendChild(deleteButton);  
      studyTaskList.appendChild(item);  
    });
  });
}

function saveStudyTasks() {
  localStorage.setItem("manodayaStudyTasks", JSON.stringify(studyTasks));
}

if (addStudyTaskButton) {
  addStudyTaskButton.addEventListener("click", () => {
    const day = document.getElementById("studyDay").value;
    const subject = document.getElementById("studySubject").value;
    const time = document.getElementById("studyTime").value;
    const duration = document.getElementById("studyDuration").value;

    if (!day || !subject || !time) {
      alert("कृपया सभी जानकारी भरें।");
      return;
    }

    studyTasks.push({
      id: Date.now(),
      day,
      subject,
      time,
      duration,
      completed: false
    });

    saveStudyTasks();
    displayStudyTasks();
    updateStudyProgress();

    document.getElementById("studyDay").value = "";
    document.getElementById("studySubject").value = "";
    document.getElementById("studyTime").value = "";
    document.getElementById("studyDuration").value = "30";
  });
}

displayStudyTasks();

// ===============================
// STUDY PROGRESS TRACKER
// ===============================

function updateStudyProgress() {
  const total = studyTasks.length;
  const completed = studyTasks.filter(task => task.completed).length;
  const remaining = total - completed;
  const percentage = total === 0 ? 0 : Math.round((completed / total) * 100);

  const totalElem = document.getElementById("totalStudyTasks");
  const compElem = document.getElementById("completedStudyTasks");
  const remElem = document.getElementById("remainingStudyTasks");
  const barElem = document.getElementById("studyProgressBar");
  const textElem = document.getElementById("studyProgressText");

  if (totalElem) totalElem.textContent = total;
  if (compElem) compElem.textContent = completed;
  if (remElem) remElem.textContent = remaining;
  if (barElem) barElem.style.width = percentage + "%";
  if (textElem) textElem.textContent = percentage + "% Completed";
}

updateStudyProgress();

// ===============================
// SMART FOCUS TIMER
// ===============================

let focusSeconds = 25 * 60;
let focusInterval = null;
let isBreakTime = false;

const focusDisplay = document.getElementById("focusTimerDisplay");
const focusMessage = document.getElementById("focusTimerMessage");

function updateFocusDisplay() {
  if (!focusDisplay) return;
  const minutes = Math.floor(focusSeconds / 60);
  const seconds = focusSeconds % 60;
  focusDisplay.textContent = String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
}

function startFocusTimer() {
  if (focusInterval !== null) return;

  if (focusMessage) {
    focusMessage.textContent = isBreakTime ? "आराम का समय है। थोड़ा ब्रेक लें!" : "Focus Session चल रहा है। पढ़ाई जारी रखें!";
  }

  focusInterval = setInterval(() => {
    if (focusSeconds > 0) {
      focusSeconds--;
      updateFocusDisplay();
      return;
    }

    clearInterval(focusInterval);  
    focusInterval = null;  

    if (!isBreakTime) {  
      isBreakTime = true;  
      focusSeconds = 5 * 60;  
      if (focusMessage) focusMessage.textContent = "शानदार! अब 5 मिनट का ब्रेक लें।";  
    } else {  
      isBreakTime = false;  
      focusSeconds = 25 * 60;  
      if (focusMessage) focusMessage.textContent = "ब्रेक पूरा हुआ! अगला 25 मिनट का Focus Session तैयार है।";  
    }  

    updateFocusDisplay();
  }, 1000);
}

function pauseFocusTimer() {
  if (focusInterval !== null) {
    clearInterval(focusInterval);
    focusInterval = null;
    if (focusMessage) focusMessage.textContent = "Timer Pause है।";
  }
}

function resetFocusTimer() {
  clearInterval(focusInterval);
  focusInterval = null;
  isBreakTime = false;
  focusSeconds = 25 * 60;
  updateFocusDisplay();
  if (focusMessage) focusMessage.textContent = "Timer Reset हो गया। फिर से शुरू करें!";
}

const startTimerBtn = document.getElementById("startFocusTimer");
const pauseTimerBtn = document.getElementById("pauseFocusTimer");
const resetTimerBtn = document.getElementById("resetFocusTimer");

if (startTimerBtn) startTimerBtn.addEventListener("click", startFocusTimer);
if (pauseTimerBtn) pauseTimerBtn.addEventListener("click", pauseFocusTimer);
if (resetTimerBtn) resetTimerBtn.addEventListener("click", resetFocusTimer);

updateFocusDisplay();

// ===============================
// DAILY STUDY STREAK & ACHIEVEMENTS
// ===============================

const streakCount = document.getElementById("streakCount");
const streakMessage = document.getElementById("streakMessage");
const achievementText = document.getElementById("achievementText");

let studyDates = JSON.parse(localStorage.getItem("manodayaStudyDates") || "[]");

function getTodayDate() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getTodayDateFromDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function calculateStreak() {
  const dates = [...new Set(studyDates)].sort().reverse();
  let streak = 0;
  const checkDate = new Date();

  if (dates[0] !== getTodayDate()) {
    checkDate.setDate(checkDate.getDate() - 1);
  }

  for (const date of dates) {
    const expectedDate = getTodayDateFromDate(checkDate);
    if (date === expectedDate) {  
      streak++;  
      checkDate.setDate(checkDate.getDate() - 1);  
    } else {  
      break;  
    }
  }
  return streak;
}

function updateStreak() {
  if (!streakCount) return;
  const streak = calculateStreak();
  streakCount.textContent = streak;

  if (studyDates.includes(getTodayDate())) {
    if (streakMessage) streakMessage.textContent = "बहुत अच्छा! आज की पढ़ाई पूरी करके आपने Streak बनाए रखी है।";
  } else {
    if (streakMessage) streakMessage.textContent = "आज कम से कम एक Study Task पूरा करके अपनी Streak बनाए रखें।";
  }

  const achievements = [];
  if (streak >= 1) achievements.push("🥉 1 Day Streak");
  if (streak >= 3) achievements.push("🥈 3 Days Streak");
  if (streak >= 7) achievements.push("🥇 7 Days Streak");
  if (streak >= 15) achievements.push("🏆 15 Days Streak");
  if (streak >= 30) achievements.push("👑 30 Days Streak");

  if (achievementText) {
    achievementText.textContent = achievements.length ? achievements.join(" | ") : "अभी कोई Achievement नहीं मिली।";
  }
}

if (studyTaskList) {
  studyTaskList.addEventListener("click", function(event) {
    if (event.target.tagName === "BUTTON" && event.target.textContent.trim() === "Mark Complete") {
      const today = getTodayDate();
      if (!studyDates.includes(today)) {  
        studyDates.push(today);  
        localStorage.setItem("manodayaStudyDates", JSON.stringify(studyDates));  
      }  
      updateStreak();
    }
  }, true);
}

updateStreak();

// ===============================
//FEEDBACK & CHAT HISTORY & MEMORY
// ===============================

const submitFeedbackButton = document.getElementById("submitFeedback");
if (submitFeedbackButton) {
  submitFeedbackButton.addEventListener("click", async () => {
    const rating = document.getElementById("feedbackRating").value;
    const message = document.getElementById("feedbackMessage").value.trim();
    const status = document.getElementById("feedbackStatus");

    if (!rating || !message) {
      status.textContent = "कृपया Rating और Feedback दोनों भरें।";
      return;
    }

    const token = localStorage.getItem("manodayaToken");
    if (!token) {
      status.textContent = "Feedback भेजने के लिए पहले Login करें।";
      return;
    }

    submitFeedbackButton.disabled = true;
    status.textContent = "Feedback भेजा जा रहा है...";

    try {
      const response = await fetch(API+"/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ rating: Number(rating), message: message })
      });

      const responseText = await response.text();  
      if (!response.ok) throw new Error(responseText || "Feedback भेजा नहीं जा सका।");  

      status.textContent = "✅ " + responseText;  
      document.getElementById("feedbackRating").value = "";  
      document.getElementById("feedbackMessage").value = "";
    } catch (error) {
      status.textContent = "❌ " + error.message;
    } finally {
      submitFeedbackButton.disabled = false;
    }
  });
}

const loadHistoryButton = document.getElementById("loadHistory");
const savedChatHistory = document.getElementById("savedChatHistory");

if (loadHistoryButton && savedChatHistory) {
  loadHistoryButton.addEventListener("click", async function() {
    const token = localStorage.getItem("manodayaToken");
    if (!token) {
      savedChatHistory.textContent = "Chat History देखने के लिए पहले Login करें।";
      return;
    }

    loadHistoryButton.disabled = true;
    savedChatHistory.textContent = "History लोड हो रही है...";

    try {
      const response = await fetch(API+"/api/history", {
        headers: { "Authorization": "Bearer " + token }
      });
      const data = await response.json();  

      if (!response.ok) throw new Error(data.message || "History लोड नहीं हुई।");  

      savedChatHistory.replaceChildren();  
      if (!data.chats || data.chats.length === 0) {  
        savedChatHistory.textContent = "अभी कोई पुरानी बातचीत सेव नहीं है।";  
        return;  
      }  

      data.chats.slice().reverse().forEach(chat => {  
        const item = document.createElement("div");  
        item.className = "history-item";  

        const question = document.createElement("p");  
        question.textContent = "आप: " + chat.userMessage;  

        const answer = document.createElement("p");  
        answer.textContent = "Manodaya AI: " + chat.botReply;  

        const date = document.createElement("small");  
        date.textContent = new Date(chat.createdAt).toLocaleString("hi-IN");  

        item.append(question, answer, date);  
        savedChatHistory.appendChild(item);  
      });
    } catch (error) {
      savedChatHistory.textContent = error.message;
    } finally {
      loadHistoryButton.disabled = false;
    }
  });
}

// ===============================
// SPEECH RECOGNITION & SYNTHESIS
// ===============================

const voiceButton = document.getElementById("startVoiceInput");
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
console.log("SpeechRecognition:", SpeechRecognition);

if (SpeechRecognition && voiceButton) {
  const recognition = new SpeechRecognition();
  recognition.lang = "hi-IN";
  recognition.continuous = false;
  recognition.interimResults = false;

  voiceButton.addEventListener("click", () => {
    recognition.start();
    voiceButton.textContent = "🎙️ सुन रहा हूँ...";
    voiceButton.disabled = true;
  });

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userMessage.value = transcript;
  };

  recognition.onend = () => {
    voiceButton.textContent = "🎤 बोलकर पूछें";
    voiceButton.disabled = false;
  };

  recognition.onerror = (event) => {
    console.log("Voice Input error:", event.error);
    voiceButton.textContent = "🎤 दोबारा बोलें";
    voiceButton.disabled = false;
  };
} else if (voiceButton) {
  voiceButton.disabled = true;
  voiceButton.textContent = "Voice समर्थित नहीं";
}

const speakReplyButton = document.getElementById("speakReply");
if (speakReplyButton) {
  speakReplyButton.addEventListener("click", () => {
    const botMessages = chatBox.querySelectorAll(".bot-message");
    if (botMessages.length === 0) return;

    const lastReply = botMessages[botMessages.length - 1].textContent;
    if (!("speechSynthesis" in window)) {
      alert("आपका Browser Voice Output Support नहीं करता।");
      return;
    }

    window.speechSynthesis.cancel();
    const speech = new SpeechSynthesisUtterance(lastReply);
    speech.lang = "hi-IN";
    speech.rate = 0.9;
    window.speechSynthesis.speak(speech);
  });
}

// ===============================
// SMART STUDY PLANNER FIX & DOWNLOAD
// ===============================

const generateStudyPlanBtn = document.getElementById("generateStudyPlan");

if (generateStudyPlanBtn) {
  generateStudyPlanBtn.addEventListener("click", function () {
    const subjectSelect = document.getElementById("plannerSubjects");
    const minutesInput = document.getElementById("plannerMinutes");
    const resultBox = document.getElementById("smartPlanResult");

    const subjects = Array.from(subjectSelect.selectedOptions)
      .map(option => option.value);

    const totalMinutes = Number(minutesInput.value);

    if (subjects.length === 0) {
      alert("कृपया कम से कम एक Subject चुनें।");
      return;
    }

    if (!totalMinutes || totalMinutes < 1) {
      alert("कृपया Study Time सही भरें।");
      return;
    }

    const eachMinutes = Math.floor(totalMinutes / subjects.length);
    const extraMinutes = totalMinutes % subjects.length;

    const plan = subjects.map((subject, index) => ({
      subject: subject,
      duration: eachMinutes + (index < extraMinutes ? 1 : 0),
      status: "Pending"
    }));

    const savedData = {
      dailyMinutes: totalMinutes,
      plan: plan
    };

    localStorage.setItem(
      "manodayaSmartPlan",
      JSON.stringify(savedData)
    );

    renderSmartPlan(plan, resultBox);

    alert("आपका Study Plan तैयार है!");
  });
}

document.addEventListener("DOMContentLoaded", function () {
  const savedPlan = localStorage.getItem("manodayaSmartPlan");
  const resultBox = document.getElementById("smartPlanResult");

  if (!savedPlan || !resultBox) return;

  try {
    const saved = JSON.parse(savedPlan);
    if (Array.isArray(saved.plan)) {
      renderSmartPlan(saved.plan, resultBox);
    }
  } catch (error) {
    console.warn("Saved plan load नहीं हुआ:", error);
  }
});

function renderSmartPlan(plan, resultBox) {
  resultBox.textContent = "";

  const heading = document.createElement("h4");
  heading.textContent = "📚 आपका Smart Study Plan";
  resultBox.appendChild(heading);

  plan.forEach((task) => {
    const item = document.createElement("label");
    item.style.display = "block";
    item.style.margin = "12px 0";

    const checkbox = document.createElement("input");  
    checkbox.type = "checkbox";  
    checkbox.checked = task.status === "Completed";  

    const text = document.createElement("span");  
    text.textContent = " " + task.subject + " — " + task.duration + " मिनट";  

    checkbox.addEventListener("change", function () {  
      task.status = checkbox.checked ? "Completed" : "Pending";  
      const saved = JSON.parse(localStorage.getItem("manodayaSmartPlan") || "{}");  
      saved.plan = plan;  
      localStorage.setItem("manodayaSmartPlan", JSON.stringify(saved));  

      text.textContent = " " + task.subject + " — " + task.duration + " मिनट (" + task.status + ")";  
    });  

    item.appendChild(checkbox);  
    item.appendChild(text);  
    resultBox.appendChild(item);
  });
}

const downloadPlanBtn = document.getElementById("downloadStudyPlan");
if (downloadPlanBtn) {
  downloadPlanBtn.addEventListener("click", function () {
    const savedData = localStorage.getItem("manodayaSmartPlan");

    if (!savedData) {  
      alert("पहले अपना Study Plan Generate करें।");  
      return;  
    }  

    try {  
      const saved = JSON.parse(savedData);  
      if (!Array.isArray(saved.plan) || saved.plan.length === 0) {  
        alert("Download करने के लिए कोई Plan नहीं है।");  
        return;  
      }  

      let content = "MANODAYA AI - SMART STUDY PLAN\n\n";  
      content += "Daily Study Time: " + saved.dailyMinutes + " Minutes\n\n";  

      saved.plan.forEach((task, index) => {  
        content += (index + 1) + ". " + task.subject;  
        content += " - " + task.duration + " Minutes";  
        content += " - " + task.status + "\n";  
      });  

      const file = new Blob([content], { type: "text/plain;charset=utf-8" });  
      const url = URL.createObjectURL(file);  
      const link = document.createElement("a");  

      link.href = url;  
      link.download = "Manodaya-Study-Plan.txt";  
      link.click();  
      URL.revokeObjectURL(url);  
    } catch (error) {  
      alert("Study Plan Download नहीं हो पाया।");  
    }
  });
}

// ===============================
// STUDENT MEMORY - SAVE & LOAD
// ===============================

const saveMemoryButton = document.getElementById("saveMemory");
const loadMemoryButton = document.getElementById("loadMemory");
const memoryInput = document.getElementById("memoryInput");
const memoryStatus = document.getElementById("memoryStatus");
const memoryList = document.getElementById("memoryList");

// SAVE MEMORY
if (saveMemoryButton) {
  saveMemoryButton.addEventListener("click", async function () {
    const memory = memoryInput.value.trim();
    const token = localStorage.getItem("manodayaToken");

    if (!memory) {
      memoryStatus.textContent = "कृपया Memory लिखें।";
      return;
    }

    if (!token) {
      memoryStatus.textContent = "पहले Login करें।";
      return;
    }

    try {
      const response = await fetch(API + "/api/memory", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ memory: memory })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Memory सेव नहीं हुई।");
      }

      memoryStatus.textContent = "✅ " + data.message;
      memoryInput.value = "";

    } catch (error) {
      memoryStatus.textContent = "❌ " + error.message;
    }
  });
}

// LOAD MEMORY
if (loadMemoryButton) {
  loadMemoryButton.addEventListener("click", async function () {
    const token = localStorage.getItem("manodayaToken");

    if (!token) {
      memoryStatus.textContent = "पहले Login करें।";
      return;
    }

    try {
      const response = await fetch(API + "/api/memory", {
        headers: {
          "Authorization": "Bearer " + token
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Memory लोड नहीं हुई।");
      }

      memoryList.replaceChildren();

      if (!data.memories || data.memories.length === 0) {
        memoryList.textContent = "अभी कोई Memory सेव नहीं है।";
        return;
      }

      data.memories.slice().reverse().forEach(function (item) {
        const paragraph = document.createElement("p");
        paragraph.textContent = "📝 " + item.memory;
        memoryList.appendChild(paragraph);
      });

      memoryStatus.textContent = "✅ Memory लोड हो गई।";

    } catch (error) {
      memoryStatus.textContent = "❌ " + error.message;
    }
  });
}

// ===============================
 // STUDY REMINDERS
 // ===============================

const addReminderButton = document.getElementById("addReminder");
const reminderTitle = document.getElementById("reminderTitle");
const reminderDate = document.getElementById("reminderDate");
const reminderTime = document.getElementById("reminderTime");
const reminderStatus = document.getElementById("reminderStatus");
const reminderList = document.getElementById("reminderList");

let studyReminders = JSON.parse(
  localStorage.getItem("manodayaReminders") || "[]"
);

function renderReminders() {
  reminderList.replaceChildren();

  studyReminders.forEach(function (reminder, index) {
    const item = document.createElement("p");
    item.textContent =
      "📚 " + reminder.title + " | " +
      reminder.date + " | " + reminder.time;

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.textContent = "Delete";

    deleteButton.addEventListener("click", function () {
      studyReminders.splice(index, 1);
      localStorage.setItem(
        "manodayaReminders",
        JSON.stringify(studyReminders)
      );
      renderReminders();
    });

    item.appendChild(deleteButton);
    reminderList.appendChild(item);
  });
}

if (addReminderButton) {
  addReminderButton.addEventListener("click", function () {
    const title = reminderTitle.value.trim();
    const date = reminderDate.value;
    const time = reminderTime.value;

    if (!title || !date || !time) {
      reminderStatus.textContent = "कृपया Title, Date और Time भरें।";
      return;
    }

    const selectedDate = new Date(date + "T" + time);

    if (selectedDate <= new Date()) {
      reminderStatus.textContent = "कृपया भविष्य की Date और Time चुनें।";
      return;
    }

    studyReminders.push({ title, date, time });

    localStorage.setItem(
      "manodayaReminders",
      JSON.stringify(studyReminders)
    );

    reminderTitle.value = "";
    reminderDate.value = "";
    reminderTime.value = "";

    reminderStatus.textContent = "✅ Reminder सेव हो गया!";
    renderReminders();
  });
}

renderReminders();