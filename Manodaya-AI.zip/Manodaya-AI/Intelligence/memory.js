// MANODAYA AI - MEMORY ENGINE

const memoryStore = new Map();

function saveMemory(username, information) {
  if (!username || !information) {
    return false;
  }

  if (!memoryStore.has(username)) {
    memoryStore.set(username, []);
  }

  const memories = memoryStore.get(username);

  memories.push({
    information: String(information).slice(0, 500),
    createdAt: new Date().toISOString()
  });

  return true;
}

function getMemory(username) {
  return memoryStore.get(username) || [];
}

function clearMemory(username) {
  return memoryStore.delete(username);
}

module.exports = {
  saveMemory,
  getMemory,
  clearMemory
};