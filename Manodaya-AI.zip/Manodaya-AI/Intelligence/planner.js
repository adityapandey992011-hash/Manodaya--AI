// MANODAYA AI - PLANNER ENGINE

function createStudyPlan(subjects, dailyMinutes) {
  if (!Array.isArray(subjects) || subjects.length === 0) {
    return [];
  }

  const availableTime = Number(dailyMinutes);

  if (!Number.isFinite(availableTime) || availableTime < 1) {
    return [];
  }

  const minutesPerSubject = Math.floor(
    availableTime / subjects.length
  );

  return subjects.map((subject, index) => ({
    id: index + 1,
    subject: String(subject),
    duration: minutesPerSubject,
    status: "Pending"
  }));
}

function getPendingTasks(plan) {
  return plan.filter(task => task.status === "Pending");
}

function completeTask(plan, taskId) {
  const task = plan.find(task => task.id === taskId);

  if (!task) return false;

  task.status = "Completed";
  return true;
}

module.exports = {
  createStudyPlan,
  getPendingTasks,
  completeTask
};