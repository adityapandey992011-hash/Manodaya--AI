// MANODAYA AI - REASONING ENGINE

function analyzeQuestion(question) {
  if (!question || typeof question !== "string") {
    return {
      success: false,
      message: "कृपया सही सवाल लिखें।"
    };
  }

  const text = question.toLowerCase();

  let subject = "General";
  let intent = "Information";

  if (/biology|जीव विज्ञान|cell|कोशिका|पौध|मानव शरीर/.test(text)) {
    subject = "Biology";
  } else if (/physics|भौतिक|बल|गति|ऊर्जा|न्यूटन/.test(text)) {
    subject = "Physics";
  } else if (/chemistry|रसायन|परमाणु|अणु|अभिक्रिया/.test(text)) {
    subject = "Chemistry";
  } else if (/math|गणित|समीकरण|त्रिकोणमिति/.test(text)) {
    subject = "Mathematics";
  }

  if (/explain|समझाओ|समझाइए|क्यों|कैसे/.test(text)) {
    intent = "Explanation";
  } else if (/quiz|प्रश्न|test|परीक्षा/.test(text)) {
    intent = "Practice";
  } else if (/notes|नोट्स|लिखो|परिभाषा/.test(text)) {
    intent = "Notes";
  }

  return {
    success: true,
    question: question.trim(),
    subject,
    intent
  };
}

module.exports = {
  analyzeQuestion
};