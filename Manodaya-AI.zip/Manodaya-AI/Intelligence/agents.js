// MANODAYA AI - AGENT MANAGER

const Memory = require("./memory");
const Learning = require("./learning");
const Planner = require("./planner");
const Reasoning = require("./reasoning");

function processStudentQuestion(username, question) {
  const analysis = Reasoning.analyzeQuestion(question);

  if (!analysis.success) {
    return analysis;
  }

  return {
    success: true,
    agent: "Manodaya Study Agent",
    analysis,
    memories: Memory.getMemory(username),
    message: "आपका सवाल विश्लेषण के लिए तैयार है।"
  };
}

function saveStudentLearning(username, feedback) {
  return Learning.recordFeedback(username, feedback);
}

function createStudentPlan(subjects, dailyMinutes) {
  return Planner.createStudyPlan(subjects, dailyMinutes);
}

module.exports = {
  processStudentQuestion,
  saveStudentLearning,
  createStudentPlan
};