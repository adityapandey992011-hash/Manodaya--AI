// MANODAYA AI - LEARNING ENGINE

const learningData = new Map();

function recordFeedback(username, feedback) {
  if (!username || !feedback) {
    return false;
  }

  if (!learningData.has(username)) {
    learningData.set(username, []);
  }

  learningData.get(username).push({
    feedback: String(feedback).slice(0, 500),
    createdAt: new Date().toISOString()
  });

  return true;
}

function getLearningData(username) {
  return learningData.get(username) || [];
}

function getLearningSummary(username) {
  const records = getLearningData(username);

  return {
    totalFeedback: records.length,
    recentFeedback: records.slice(-5)
  };
}

module.exports = {
  recordFeedback,
  getLearningData,
  getLearningSummary
};