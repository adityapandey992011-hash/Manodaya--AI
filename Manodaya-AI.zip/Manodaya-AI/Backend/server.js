const cors = require("cors");

app.use(cors({
  origin: "http://192.168.1.4:5501",
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

app.use(express.json());
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
// MANODAYA INTELLIGENCE ENGINE
const Agents = require("../Intelligence/agents");

const PORT = process.env.PORT || 3001;
const FRONTEND = path.join(__dirname, "..", "Frontend");
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "database.json");

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(
    DATA_FILE,
    JSON.stringify({ students: [] }, null, 2)
  );
}

function readDB() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { students: [] };
  }
}

function writeDB(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

const sessions = new Map();

const allowedStreams = [
  "PCB",
  "PCM",
  "PCMB",
  "Commerce",
  "Arts",
  "Agriculture",
  "Vocational"
];

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8"
};

function send(res, status, data, type = "application/json; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type });
  res.end(
    type.startsWith("application/json")
      ? JSON.stringify(data)
      : data
  );
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";

    req.on("data", chunk => {
      body += chunk;

      if (body.length > 10000) {
        reject(new Error("Request too large"));
        req.destroy();
      }
    });

    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });

    req.on("error", reject);
  });
}

function makePasswordHash(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

function createSession(studentId) {
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, studentId);
  return token;
}

function getStudentFromToken(req) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ")
    ? auth.slice(7)
    : "";

  const studentId = sessions.get(token);

  if (!studentId) return null;

  const db = readDB();

  return db.students.find(
    student => student.id === studentId
  ) || null;
}

function publicStudent(student) {
  return {
    name: student.name,
    username: student.username,
    studentClass: student.studentClass,
    stream: student.stream || "Not selected",
    subjects: student.subjects || []
  };
}

const server = http.createServer(async (req, res) => {
  // CORS CONFIGURATION
res.setHeader("Access-Control-Allow-Origin", "http://127.0.0.1:5500");
res.setHeader("Access-Control-Allow-Methods", "GET, POST,PUT, OPTIONS");
res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

if (req.method === "OPTIONS") {
  res.writeHead(204);
  return res.end();
}
  const pathname = new URL(
    req.url,
    "http://localhost"
  ).pathname;

  // REGISTER
  if (req.method === "POST" && pathname === "/api/register") {
    try {
      const body = await readBody(req);

      const name = String(body.name || "").trim().slice(0, 60);
      const username = String(body.username || "").trim().toLowerCase();
      const password = String(body.password || "");
      const studentClass = String(body.studentClass || "");
      const stream = String(body.stream || "");
const subjects = Array.isArray(body.subjects)
  ? [...new Set(
      body.subjects
        .filter(s => typeof s === "string")
        .map(s => s.trim())
        .filter(Boolean)
    )].slice(0, 10)
  : [];
      if (!name || !/^[a-z0-9_]{3,20}$/.test(username)) {
        return send(res, 400, {
          success: false,
          message: "Name या Username सही नहीं है। Username 3-20 अक्षर का रखें।"
        });
      }

      if (password.length < 8 || password.length > 128) {
        return send(res, 400, {
          success: false,
          message: "Password कम से कम 8 अक्षर का होना चाहिए।"
        });
      }

      if (!["11", "12"].includes(studentClass)) {
        return send(res, 400, {
          success: false,
          message: "Class 11 या 12 चुनें।"
        });
      }

      if (!allowedStreams.includes(stream)) {
        return send(res, 400, {
          success: false,
          message: "कृपया सही Stream चुनें।"
        });
      }

      const db = readDB();

      if (db.students.some(s => s.username === username)) {
        return send(res, 409, {
          success: false,
          message: "यह Username पहले से मौजूद है।"
        });
      }

      const salt = crypto.randomBytes(16).toString("hex");

      const student = {
  id: crypto.randomUUID(),
  name,
  username,
  studentClass,
  stream,
  subjects,
  salt,
  passwordHash: makePasswordHash(password, salt)
};

      db.students.push(student);
      writeDB(db);

      const token = createSession(student.id);

      return send(res, 201, {
        success: true,
        token,
        student: publicStudent(student)
      });

    } catch {
      return send(res, 400, {
        success: false,
        message: "Registration पूरी नहीं हो सकी।"
      });
    }
  }

  // LOGIN
  if (req.method === "POST" && pathname === "/api/login") {
    try {
      const body = await readBody(req);

      const username = String(body.username || "").trim().toLowerCase();
      const password = String(body.password || "");

      const db = readDB();

      const student = db.students.find(
        s => s.username === username
      );

      if (!student || password.length > 128) {
        return send(res, 401, {
          success: false,
          message: "Username या Password गलत है।"
        });
      }

      const attemptedHash = makePasswordHash(
        password,
        student.salt
      );

      const savedHash = Buffer.from(
        student.passwordHash,
        "hex"
      );

      const enteredHash = Buffer.from(
        attemptedHash,
        "hex"
      );

      if (
        savedHash.length !== enteredHash.length ||
        !crypto.timingSafeEqual(savedHash, enteredHash)
      ) {
        return send(res, 401, {
          success: false,
          message: "Username या Password गलत है।"
        });
      }

      const token = createSession(student.id);

      return send(res, 200, {
        success: true,
        token,
        student: publicStudent(student)
      });

    } catch {
      return send(res, 400, {
        success: false,
        message: "Login नहीं हो सका।"
      });
    }
  }
  
// UPDATE STUDENT PROFILE
if (req.method === "PUT" && pathname === "/api/profile") {
  const currentStudent = getStudentFromToken(req);

  if (!currentStudent) {
    return send(res, 401, {
      success: false,
      message: "कृपया पहले Login करें।"
    });
  }

  const body = await readBody(req);
  const db = readDB();

  const student = db.students.find(
    s => s.id === currentStudent.id
  );

  if (!student) {
    return send(res, 404, {
      success: false,
      message: "Student नहीं मिला।"
    });
  }

  const name = String(body.name || "").trim();
  const studentClass = String(body.studentClass || "");
  const stream = String(body.stream || "");
  const subjects = Array.isArray(body.subjects)
    ? [...new Set(body.subjects.filter(s => typeof s === "string"))]
    : [];

  const allowedStreams = [
    "PCB", "PCM", "PCMB", "Commerce",
    "Arts", "Agriculture", "Vocational"
  ];

  if (!name || !["11", "12"].includes(studentClass) ||
      !allowedStreams.includes(stream)) {
    return send(res, 400, {
      success: false,
      message: "कृपया सही जानकारी भरें।"
    });
  }

  student.name = name;
  student.studentClass = studentClass;
  student.stream = stream;
  student.subjects = subjects;

  writeDB(db);

  return send(res, 200, {
    success: true,
    message: "Profile Update हो गई।",
    student: publicStudent(student)
  });
}

  // CURRENT STUDENT
  if (req.method === "GET" && pathname === "/api/me") {
    const student = getStudentFromToken(req);

    if (!student) {
      return send(res, 401, {
        success: false,
        message: "Login आवश्यक है।"
      });
    }

    return send(res, 200, {
      success: true,
      student: publicStudent(student)
    });
  }

  // LOGOUT
  if (req.method === "POST" && pathname === "/api/logout") {
    const auth = req.headers.authorization || "";

    const token = auth.startsWith("Bearer ")
      ? auth.slice(7)
      : "";

    sessions.delete(token);

    return send(res, 200, {
      success: true,
      message: "Logout हो गया।"
    });
  }

  // SERVER HEALTH
  if (req.method === "GET" && pathname === "/api/health") {
    return send(res, 200, {
      success: true,
      message: "Manodaya AI Backend is running!"
    });
  }
// STUDENT FEEDBACK API
  if (req.method === "POST" && pathname === "/api/feedback") {
    try {
      const student = getStudentFromToken(req);

      if (!student) {
        return send(res, 401, {
          success: false,
          message: "Feedback भेजने के लिए Login करें।"
        });
      }

      const body = await readBody(req);

      const message = String(body.message || "").trim();
      const rating = Number(body.rating);

      if (!message || message.length > 1000) {
        return send(res, 400, {
          success: false,
          message: "Feedback 1 से 1000 अक्षरों के बीच होना चाहिए।"
        });
      }

      if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
        return send(res, 400, {
          success: false,
          message: "कृपया 1 से 5 के बीच Rating चुनें।"
        });
      }

      const feedbackFile = path.join(DATA_DIR, "feedback.json");

      let feedbackDB = { feedback: [] };

      if (fs.existsSync(feedbackFile)) {
        feedbackDB = JSON.parse(
          fs.readFileSync(feedbackFile, "utf8")
        );
      }

      if (!Array.isArray(feedbackDB.feedback)) {
        feedbackDB.feedback = [];
      }

      feedbackDB.feedback.push({
        id: crypto.randomUUID(),
        username: student.username,
        message,
        rating,
        createdAt: new Date().toISOString()
      });

// SEND FEEDBACK TO LEARNING ENGINE
Agents.saveStudentLearning(
  student.username,
  message
);
      fs.writeFileSync(
        feedbackFile,
        JSON.stringify(feedbackDB, null, 2)
      );

      return send(res, 201, {
        success: true,
        message: "आपका Feedback सफलतापूर्वक सेव हो गया।"
      });

    } catch {
      return send(res, 400, {
        success: false,
        message: "Feedback सेव नहीं हो सका।"
      });
    }
  }
  // =====================================
// CHAT HISTORY API
// =====================================

// SAVE CHAT
if (req.method === "POST" && pathname === "/api/history") {
  try {
    const student = getStudentFromToken(req);

    if (!student) {
      return send(res, 401, {
        success: false,
        message: "पहले Login करें।"
      });
    }

    const body = await readBody(req);

    const userText = String(body.userMessage || "").trim();
    const botText = String(body.botReply || "").trim();

    if (
      !userText ||
      !botText ||
      userText.length > 2000 ||
      botText.length > 2000
    ) {
      return send(res, 400, {
        success: false,
        message: "Chat Message सही नहीं है।"
      });
    }

    const historyFile = path.join(DATA_DIR, "history.json");

    let historyDB = { chatHistory: [], activities: [] };

    if (fs.existsSync(historyFile)) {
      historyDB = JSON.parse(
        fs.readFileSync(historyFile, "utf8")
      );
    }

    if (!Array.isArray(historyDB.chatHistory)) {
      historyDB.chatHistory = [];
    }

    historyDB.chatHistory.push({
      id: crypto.randomUUID(),
      username: student.username,
      userMessage: userText,
      botReply: botText,
      createdAt: new Date().toISOString()
    });

    fs.writeFileSync(
      historyFile,
      JSON.stringify(historyDB, null, 2)
    );

    return send(res, 201, {
      success: true,
      message: "Chat History सेव हो गई।"
    });

  } catch {
    return send(res, 400, {
      success: false,
      message: "Chat History सेव नहीं हो सकी।"
    });
  }
}

// GET CHAT HISTORY
if (req.method === "GET" && pathname === "/api/history") {
  const student = getStudentFromToken(req);

  if (!student) {
    return send(res, 401, {
      success: false,
      message: "पहले Login करें।"
    });
  }

  try {
    const historyFile = path.join(DATA_DIR, "history.json");

    const historyDB = JSON.parse(
      fs.readFileSync(historyFile, "utf8")
    );

    const chats = (historyDB.chatHistory || [])
      .filter(chat => chat.username === student.username)
      .slice(-50);

    return send(res, 200, {
      success: true,
      chats
    });

  } catch {
    return send(res, 200, {
      success: true,
      chats: []
    });
  }
}
// =====================================
// STUDENT MEMORY API
// =====================================

// SAVE MEMORY
if (req.method === "POST" && pathname === "/api/memory") {
  try {
    const student = getStudentFromToken(req);

    if (!student) {
      return send(res, 401, {
        success: false,
        message: "पहले Login करें।"
      });
    }

    const body = await readBody(req);
    const memoryText = String(body.memory || "").trim();

    if (!memoryText || memoryText.length > 500) {
      return send(res, 400, {
        success: false,
        message: "Memory 1 से 500 अक्षरों के बीच होनी चाहिए।"
      });
    }

    const memoryFile = path.join(DATA_DIR, "memory.json");
    let memoryDB = { studentMemory: [] };

    if (fs.existsSync(memoryFile)) {
      memoryDB = JSON.parse(fs.readFileSync(memoryFile, "utf8"));
    }

    if (!Array.isArray(memoryDB.studentMemory)) {
      memoryDB.studentMemory = [];
    }

    memoryDB.studentMemory.push({
      id: crypto.randomUUID(),
      username: student.username,
      memory: memoryText,
      createdAt: new Date().toISOString()
    });

    memoryDB.studentMemory = memoryDB.studentMemory.slice(-500);

    fs.writeFileSync(
      memoryFile,
      JSON.stringify(memoryDB, null, 2)
    );

    return send(res, 201, {
      success: true,
      message: "Student Memory सेव हो गई।"
    });

  } catch {
    return send(res, 400, {
      success: false,
      message: "Memory सेव नहीं हो सकी।"
    });
  }
}

// GET MY MEMORY
if (req.method === "GET" && pathname === "/api/memory") {
  const student = getStudentFromToken(req);

  if (!student) {
    return send(res, 401, {
      success: false,
      message: "पहले Login करें।"
    });
  }

  try {
    const memoryFile = path.join(DATA_DIR, "memory.json");
    const memoryDB = JSON.parse(
      fs.readFileSync(memoryFile, "utf8")
    );

    const memories = (memoryDB.studentMemory || [])
      .filter(item => item.username === student.username)
      .slice(-50);

    return send(res, 200, {
      success: true,
      memories
    });

  } catch {
    return send(res, 200, {
      success: true,
      memories: []
    });
  }
}
// =====================================
// MANODAYA INTELLIGENCE API
// =====================================

if (req.method === "POST" && pathname === "/api/intelligence/analyze") {
  try {
    const student = getStudentFromToken(req);

    if (!student) {
      return send(res, 401, {
        success: false,
        message: "पहले Login करें।"
      });
    }

    const body = await readBody(req);
    const question = String(body.question || "").trim();

    if (!question || question.length > 2000) {
      return send(res, 400, {
        success: false,
        message: "सवाल 1 से 2000 अक्षरों के बीच होना चाहिए।"
      });
    }

    const result = Agents.processStudentQuestion(
      student.username,
      question
    );

    return send(res, 200, result);

  } catch (error) {
    console.error("Intelligence API Error:", error);

    return send(res, 500, {
      success: false,
      message: "Intelligence Engine में समस्या आई।"
    });
  }
}
// =====================================
// SMART PLANNER API
// =====================================

if (req.method === "POST" && pathname === "/api/planner") {
  try {
    const student = getStudentFromToken(req);

    if (!student) {
      return send(res, 401, {
        success: false,
        message: "पहले Login करें।"
      });
    }

    const body = await readBody(req);
    const subjects = body.subjects;
    const dailyMinutes = Number(body.dailyMinutes);

    if (
      !Array.isArray(subjects) ||
      subjects.length === 0 ||
      subjects.length > 10 ||
      subjects.some(s => typeof s !== "string" || !s.trim())
    ) {
      return send(res, 400, {
        success: false,
        message: "कृपया सही Subjects चुनें।"
      });
    }

    if (
      !Number.isInteger(dailyMinutes) ||
      dailyMinutes < 10 ||
      dailyMinutes > 1440
    ) {
      return send(res, 400, {
        success: false,
        message: "Daily Study Time सही नहीं है।"
      });
    }

    const plan = Agents.createStudentPlan(
      subjects,
      dailyMinutes
    );

    return send(res, 200, {
      success: true,
      plan
    });

  } catch (error) {
    console.error("Planner API Error:", error);

    return send(res, 500, {
      success: false,
      message: "Study Plan नहीं बन सका।"
    });
  }
}
  // FRONTEND FILES
  if (req.method !== "GET") {
    return send(res, 405, {
      success: false,
      message: "Method not allowed"
    });
  }

  const requestedPath =
    pathname === "/" ? "/index.html" : pathname;

  let filePath;

  try {
    filePath = path.resolve(
      FRONTEND,
      "." + decodeURIComponent(requestedPath)
    );
  } catch {
    return send(res, 400, {
      success: false,
      message: "Invalid path"
    });
  }

  if (!filePath.startsWith(FRONTEND + path.sep)) {
    return send(res, 403, {
      success: false,
      message: "Forbidden"
    });
  }

  fs.readFile(filePath, (error, content) => {
    if (error) {
      return send(
        res,
        404,
        "File Not Found",
        "text/plain; charset=utf-8"
      );
    }

    const extension = path.extname(filePath).toLowerCase();

    send(
      res,
      200,
      content,
      mimeTypes[extension] || "application/octet-stream"
    );
  });
});
app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `Manodaya AI running at http://localhost:${PORT}`
  );
});